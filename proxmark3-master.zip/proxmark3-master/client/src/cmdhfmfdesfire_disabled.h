#ifndef __MFDESFIRE_AD_H
#define __MFDESFIRE_AD_H

#include "common.h"

int CmdHFMFDesfire(const char *Cmd);

#endif
