#!/bin/bash

cd ..
make src/pm3_luawrap.c
make src/pm3_pywrap.c
