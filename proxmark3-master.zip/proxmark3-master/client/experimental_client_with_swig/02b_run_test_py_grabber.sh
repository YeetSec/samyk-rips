#!/bin/bash

../../pm3 -c "script run testembedded_grab.py" -i
