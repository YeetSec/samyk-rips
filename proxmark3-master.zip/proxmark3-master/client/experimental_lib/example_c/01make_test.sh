#!/bin/bash

gcc -o test test.c -I../../include -lpm3rrg_rdv4 -L../build -lpthread
