#!/bin/bash

PYTHONPATH=../../src ipython3 -i ./test_grab.py
