#!/bin/bash

ln -fs ../build/libpm3rrg_rdv4.so _pm3.so
