#!/bin/bash

ln -fs ../build/libpm3rrg_rdv4.so pm3.so
