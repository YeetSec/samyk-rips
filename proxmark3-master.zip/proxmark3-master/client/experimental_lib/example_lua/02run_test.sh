#!/bin/bash

# pm3.so somewhere in default LUA_CPATH :
# /usr/local/lib/lua/5.2/pm3.so
# /usr/lib/lua/5.2/pm3.so
# ./pm3.so

./test.lua
