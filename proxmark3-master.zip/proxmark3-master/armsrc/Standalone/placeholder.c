#include "standalone.h" // standalone definitions

#include "dbprint.h"

void ModInfo(void) {
    DbpString("  No standalone mode present");
}

void RunMod(void) {
}
